import 'package:etc/bloc/bloc.dart';
import 'package:etc/helper/services.dart';
import 'package:etc/pages/home.dart';
import 'package:etc/pages/offers.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

final Map<String, WidgetBuilder> routes = <String, WidgetBuilder>{
  // "/": (BuildContext context) => BlocProvider(
  //   create: (context)=>CategoriesBloc(Services())..add(GetCategories()),
  //   child:Home()
  //   ),
  "/": (BuildContext context) => MultiBlocProvider(
    providers: [
      BlocProvider<FooterBloc>(
        create: (context) => FooterBloc(),
      ),
      BlocProvider(create: (context)=>CategoriesBloc(Services())..add(GetCategories())),
      BlocProvider(create: (context)=>OffersBloc(Services())..add(GetFeaturedOffers())),
      BlocProvider(create: (context)=>BrandsBloc(Services())..add(GetPopularBrands())),
      BlocProvider(create: (context)=>EventsBloc(Services()))
    ],
    child: Home()),
  "/Offers": (BuildContext context) => Offers(),
};