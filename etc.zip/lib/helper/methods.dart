import 'package:intl/intl.dart';

class HelperMethods {
  
  Map<String,dynamic> searchArray(List<dynamic> arr, String fld, String val){
    return arr.firstWhere((item)=>item[fld]==val);
  }
  
  List<Map<String,String>> searchArrayList(List<Map<String,String>> arr, String fld, String val){
    return arr.where((item)=> item[fld]==val).toList();
  }

  String formatDateTime({String format, String dateTime}){
    if(dateTime=='' || dateTime==null){
      return dateTime;
    }
     var ndt = DateTime.parse(dateTime);
     return DateFormat(format).format(ndt);
  }
  
  String formatTime({String format, String dateTime}){
     var ndt = DateTime.parse("2020-04-20 " + dateTime);
     return DateFormat(format).format(ndt);
  }

  getSequenceArray (int val){
    var newArray = [];
    for(var i=0; i<val; i++){
      newArray.add(i);
    }
    return newArray;
  }

}