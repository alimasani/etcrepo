import 'dart:async';

import 'package:etc/helper/api.dart';
import 'package:etc/helper/data-process.dart';
import 'package:etc/helper/globals.dart';
import 'package:etc/models/categories.dart';

class Services {
  // Check System Health
  Future<List<dynamic>> checkSystemHealth(dynamic data) async {
    final url = openWebCmn + 'systemHealth';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

  // Get Redemption Processes
  Future<List<dynamic>> getRedeptionProcesses(dynamic data) async {
    final url = openWebCmn + 'redemptionProcesses';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

  // Get Filters
  Future<List<dynamic>> getFilters(dynamic data) async {
    final url = openWebCmn + 'filters';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }
  
  // Get Countries
  Future<List<dynamic>> getCountries(dynamic data) async {
    final url = openWebCmn + 'countries';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

  // Get cities
  Future<List<dynamic>> getCities(dynamic data) async {
    final url = openWeb + authWeb + apiV1 + 'cities';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }
  
  // Get categories
  Future<List<dynamic>> getCategories(dynamic data) async {
    final url = openWeb + authWeb + apiV1 + 'categories';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

  // Get brands
  Future<List<dynamic>> getBrands(dynamic data) async {
    final url = openWeb + authWeb + apiV1 + 'brands';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

  // Get Offers
  Future<List<dynamic>> getOffers(
      {dynamic data, String start = "1", String offset = rowsPerPage}) async {
    /*Request Parms: {
            mapMBR{minLat, minLong, maxLat, maxLong}, 
            brandIDs[string], 
            categoryIDs[string], 
            cityIDs[string],
            searchKeyword,
            filters[{key,value}],
            viewNewOffers,
            viewFeaturedOffers,
            userID,
            userName,
            userLocation{latitude,longitude},
            viewUserBookmarkedOffers,
            viewUserEntitledOffers
        }
        type: list, search
        */

    final url = openWeb + authWeb + apiV1 + 'offers';
    var startOffset = "";
    if (start != '0') {
      startOffset = "?start=" + start + "&offset=" + offset;
    }
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url + startOffset, headers);
    return response;
  }

  // Get Offer Details
  Future<dynamic> getOfferDetails(dynamic data) async {
    /*
        Request Parms: {
            dataRequestTypes,
            offerID,
            outletID,
            userID,
            userName,
            userLocation:{latitude,longitude}
        }*/

    final url = openWeb + authWeb + apiV1 + 'offer';
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

  // Get events
  Future<List<dynamic>> getEvents(
      {dynamic data, String start = "1", String offset = rowsPerPage}) async {
    /*Request Parms: {
            startDateTime,
            endDateTime
        }*/

    final url = openWeb + authWeb + apiV1 + 'events';
    var startOffset = "";
    if (start != '0') {
      startOffset = "?start=" + start + "&offset=" + offset;
    }
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url + startOffset, headers);
    return response;
  }
  
  // send otp
  Future<List<dynamic>> senOTP({dynamic data}) async {
    /*Request Parms: {
            userIdentity,
            otpTransferMode,
            requetContext
        }*/

    final url = openWeb + authWeb + apiV1 + 'sendOTP';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().post(url, headers);
    return response;
  }
  
  // validate otp
  Future<List<dynamic>> validateOTP({dynamic data}) async {
    /*Request Parms: {
            userIdentity,
            oneTimePassword,
            requetContext
        }*/

    final url = openWeb + authWeb + apiV1 + 'validateOTP';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().post(url, headers);
    return response;
  }
  
  // session token
  Future<List<dynamic>> getSessionToken({dynamic data}) async {
    /*Request Parms: {
            requestType,
            requestContext,
        }*/

    final url = openWeb + authWeb + apiV1 + 'manageSessionToken';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }
  
  // register device
  Future<List<dynamic>> registerDevice({String auth, dynamic data}) async {
    /*
    authorization:
    Request Parms: {
            deviceType,
            deviceID,
        }*/

    final url = openWeb + authWeb + apiV1 + 'registerDevice';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().post(url, headers);
    return response;
  }
  
  // toggle Bookmark
  Future<List<dynamic>> toggleBokmark({String auth, dynamic data}) async {
    /*
    authorization:
    Request Parms: {
            offerID,
            outletID,
        }*/

    final url = openWeb + authWeb + apiV1 + 'toggleBookmark';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().post(url, headers);
    return response;
  }
  
  // validate deal
  Future<List<dynamic>> validateDeal({String auth, dynamic data}) async {
    /*
    authorization:
    Request Parms: {
            dealID,
            redeemVoucherCountRef,
        }*/

    final url = openWeb + authWeb + apiV1 + 'validateDeal';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }
  
  // validate user
  Future<List<dynamic>> validateUser({String auth, dynamic data}) async {
    /*
    authorization:
    Request Parms: {
            userPassword,
        }*/

    final url = openWeb + authWeb + apiV1 + 'validateUser';
    
    Map<String, String> headers = {};
    if (data != '' && data != null) {
      headers['requestParams'] = DataProcess().encode("base64", data);
    }
    final response = await ApiBaseHelper().get(url, headers);
    return response;
  }

}
