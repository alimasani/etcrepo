import 'package:etc/helper/globals.dart';
import 'package:flutter/material.dart';
import 'package:etc/theme/style.dart';

class SideMenu extends StatefulWidget {
  SideMenu({Key key}) : super(key: key);

  @override
  _SideMenuState createState() => _SideMenuState();
}

class _SideMenuState extends State<SideMenu> {
  List<Color> _gradients = [primaryColor, blueColor];
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Drawer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            DrawerHeader(
              margin: EdgeInsets.fromLTRB(0.0,0.0,0.0,2.0),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: 80.0,
                      height: 80.0,
                      child: Icon(Icons.add, color:grayColor, size: 35.0,),
                      decoration: BoxDecoration(
                      color: lightGrayColor,
                      shape: BoxShape.circle,
                    ),

                    ),
                    SizedBox(height: 15.0),
                    Text("Marhaba ETC User",style:TextStyle(color: Colors.white, fontSize: 20.0))
                  ],
                ),
              ),
              decoration: BoxDecoration(
                color: primaryColor,
              ),
            ),
            Expanded(
              child: Container(
                child: Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        title: Text('How it Works', style: sideMenuText),
                      ),
                      ListTile(
                        title: Text('FAQ\'s', style: sideMenuText),
                      ),
                      ListTile(
                        title: Text('Settings', style: sideMenuText),
                      ),
                      ListTile(
                        title: Text('Rules of Use', style: sideMenuText),
                      ),
                      ListTile(
                        title: Text('Rate Us', style: sideMenuText),
                      ),
                      ListTile(
                        title: Text('Sign In', style: sideMenuText),
                      ),
                    ],
                  ),
                ),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: _gradients,
                        begin: Alignment.topCenter,
                        stops: [0.55, 1],
                        end: Alignment.bottomCenter)),
              ),
            )
          ],
        ),
      ),
    );
  }
}
