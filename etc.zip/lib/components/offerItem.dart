import 'package:etc/helper/globals.dart';
import 'package:etc/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:etc/helper/methods.dart';

class OfferItem extends StatelessWidget {
  final dynamic offerItem;
  const OfferItem({Key key, this.offerItem}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
      var formattedDate = HelperMethods().formatDateTime(format:"dd MMM yyyy",dateTime:offerItem['offerInfo']['validUntil']);    
      
      return Container(
      margin: EdgeInsets.fromLTRB(0, 10.0, 0, 5.0),
      constraints: BoxConstraints.expand(height: 100.0),
      child: Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(0.0)),
          elevation: 0.0,
          margin: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 2.0),
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                  height: 100.0,
                  width: 100.0,
                  child: Container(
                    decoration: BoxDecoration(
                      color:Color.fromRGBO(0, 0, 0, 0.7),
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0)),
                    ),
                    child: Padding(
                        padding: EdgeInsets.all(10.0),
                        child: Row(
                          children: <Widget>[
                            Container(
                              height:60.0,
                              child: Image.network(offerItem['offerInfo']['brand']
                                  ['brandLogoURL']),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                            ),
                            SizedBox(width: 10.0,),
                            Center(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    offerItem['outlet']['displayName'],
                                    style: offerTitleWhite,
                                    textAlign: TextAlign.left,
                                  ),
                                  SizedBox(height: 5.0,),
                                  Text(
                                    offerItem['outlet']['displayInfo'],
                                    style: offerInfoWhite,
                                    textAlign: TextAlign.left,
                                  )
                                ],
                              ),
                            )
                          ],
                        )),
                  ),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0)),
                      image: DecorationImage(
                          image: NetworkImage(
                              offerItem["outlet"]["defaultDisplayImage"]),
                          fit: BoxFit.cover))),
                          Container(
                            decoration: BoxDecoration(color:lightGrayColor,
                            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10.0), bottomRight:Radius.circular(10.0))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                Column(
                                  children:<Widget>[
                                    Text("kms away"),
                                    Text(offerItem['outlet']['locality']['distance'])
                                  ]
                                ),
                                Column(
                                  children:<Widget>[
                                    Text("valid until"),
                                    Text(formattedDate)
                                  ]
                                ),
                                Column(
                                  children:<Widget>[
                                    Text("avg. savings"),
                                    Text(offerItem['offerInfo']['maxAvgSavings'])
                                  ]
                                ),
                          ],),
                            ),)
            ],
          )),
    );
  }
}
