import 'package:etc/helper/globals.dart';
import 'package:etc/helper/methods.dart';
import 'package:etc/theme/style.dart';
import 'package:flutter/material.dart';

class Voucheritem extends StatelessWidget {
  final dynamic voucherItem;
  final String validUntil;
  const Voucheritem({Key key, this.voucherItem, this.validUntil})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var formattedDate = HelperMethods()
        .formatDateTime(format: "dd MMM yyyy", dateTime: validUntil);

    return Container(
      height:70.0,
      margin: EdgeInsets.fromLTRB(0, 5.0, 0, 5.0),
      child: Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(0.0)),
          elevation: 0.0,
          margin:EdgeInsets.all(0.0),
          color: Colors.white,
          child: Row(
            children: <Widget>[
              Container(
                height: 70.0,
                width:60.0,
                padding: EdgeInsets.all(0.0),
                child: Center(
                  child: Text(
                      voucherItem['discountType'], softWrap: true,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 20.0, height: 1.2, fontWeight: FontWeight.w600),
                    ),
                ),
                decoration: BoxDecoration(color: blueColor),
              ),
              Expanded(
                child: Container(
                  height: 70.0,
                  padding: EdgeInsets.fromLTRB(7.0, 4.0, 5.0, 2.0),
                  width: MediaQuery.of(context).size.width*0.8,
                  decoration: BoxDecoration(color: lightGrayColor),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                    Text(voucherItem['voucherName'], textAlign: TextAlign.left, style: TextStyle(fontSize: 17.0, fontWeight: FontWeight.w600, height: 1.3),),
                    Text(voucherItem['voucherValidities']
                            ['validForDescription'] +
                        " until " +
                        formattedDate, style: TextStyle(fontSize: 13.0, height: 1.4,),),
                    Text(voucherItem['voucherValidities']
                        ['groupRedemptionLimitDescription'],style: TextStyle(fontSize: 13.0, height: 1.4,),)
                  ]),
                ),
              )
            ],
          )),
    );
  }
}
