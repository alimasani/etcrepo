import 'package:etc/simple_bloc_delegate.dart';
import 'package:flutter/material.dart';
import 'package:etc/theme/theme.dart';
import 'package:etc/routes.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:etc/helper/globals.dart';

void main() {
  BlocSupervisor.delegate = SimpleBlocDelegate();
  runApp(EtcApp());
}

class EtcApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'ETC',
        debugShowCheckedModeBanner: (appMode=="prod")?false:true,
        theme: appTheme(),
        initialRoute: '/',
        routes: routes,
      );
  }
}