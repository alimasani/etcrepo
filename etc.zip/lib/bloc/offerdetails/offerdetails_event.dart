
import 'package:equatable/equatable.dart';

abstract class OfferdetailsEvent extends Equatable {
  const OfferdetailsEvent();
}

class GetOfferDetails extends OfferdetailsEvent {
  final String offerId;
  final String outletId;
  const GetOfferDetails({this.outletId,this.offerId});

  @override
  List<Object> get props => [];
}