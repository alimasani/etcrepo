import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:etc/helper/methods.dart';
import 'package:etc/helper/services.dart';

import '../bloc.dart';

class OfferdetailsBloc extends Bloc<OfferdetailsEvent, OfferdetailsState> {

  final Services _services;
  OfferdetailsBloc(this._services); 

  @override
  OfferdetailsState get initialState => OfferdetailsInitial();

  @override
  Stream<OfferdetailsState> mapEventToState(
    OfferdetailsEvent event,
  ) async* {
    if(event is GetOfferDetails){
        var reqParams = {};
        reqParams['outletID'] = event.outletId;
        reqParams['offerID'] = event.offerId;
        var offersList = await _services.getOfferDetails(reqParams);
        var daysArr = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

        var tmp = offersList['outlet']['workingHours']['displayWorkingHours'];

        var workingHrs = [];

        for(var ti in daysArr){
            print(ti);
            // var t = HelperMethods().searchArrayList(tmp, "weekday", "Sun");
            var t = tmp.where((x)=> x['weekday']==ti).toList();
            print(t);
            var val="";
            for(var j=0; j<t.length; j++){
              if(t[j]['startTime']!='CLOSED'){
                  if(val!='') {
                   val = val + ", " + HelperMethods().formatTime(format:"HH:mm",dateTime:t[j]['startTime']) + " to " + HelperMethods().formatTime(format:"HH:mm",dateTime:t[j]['endTime']);
                  }else {
                     val =HelperMethods().formatTime(format:"HH:mm",dateTime:t[j]['startTime']) + " to " + HelperMethods().formatTime(format:"HH:mm",dateTime:t[j]['endTime']);
                  }
              }else {
                val = "CLOSED";
              }
              
            }

            var fo = {};
            fo['weekday']=ti;
            fo['isToday']=t[0]['isToday'];
            fo['time']=val;
            
            workingHrs.add(fo);

        }

        offersList['outlet']['workingHours']['formattedWorkingHrs'] = workingHrs;

        yield OfferdetailsSuccess(offersList);
    }
  }
}
