import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:etc/helper/services.dart';

import '../bloc.dart';

class UsersBloc extends Bloc<UsersEvent, UsersState> {
  
  final Services _services;
  UsersBloc(this._services);

  @override
  UsersState get initialState => UsersInitial();

  @override
  Stream<UsersState> mapEventToState(
    UsersEvent event,
  ) async* {
    yield UsersLoading();
    if(event is LoginUser){
        // final user = await _services.login(null);
        // yield UsersSuccess(user);
  }
  }
}