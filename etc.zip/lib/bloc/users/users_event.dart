
import 'package:equatable/equatable.dart';

abstract class UsersEvent extends Equatable {
  const UsersEvent();
}


class LoginUser extends UsersEvent {
    
  const LoginUser();

  @override
  List<Object> get props => [];
}

