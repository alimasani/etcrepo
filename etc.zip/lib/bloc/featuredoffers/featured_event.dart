import 'package:equatable/equatable.dart';

abstract class FeaturedOffersEvent extends Equatable {
  const FeaturedOffersEvent();
}

class GetFeaturedOffers extends FeaturedOffersEvent {
    
  const GetFeaturedOffers();

  @override
  List<Object> get props => [];
}