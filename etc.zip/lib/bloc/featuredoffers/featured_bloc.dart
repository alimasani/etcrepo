// import 'dart:async';

// import 'package:bloc/bloc.dart';
// import 'package:equatable/equatable.dart';
// import 'package:etc/bloc/bloc.dart';
// import 'package:etc/helper/globals.dart';
// import 'package:etc/helper/services.dart';


// class FeaturedOffersBloc extends Bloc<FeaturedOffersEvent, FeaturedOffersState> {

//   final Services _services;
//   FeaturedOffersBloc(this._services);  

//   @override
//   FeaturedOffersState get initialState => FeaturedOffersInitial();

//   @override
//   Stream<FeaturedOffersState> mapEventToState(
//     FeaturedOffersEvent event,
//   ) async* {
//     yield FeaturedOffersLoading();
//     if(event is GetFeaturedOffers){
//         final offersList = await _services.getOffers(data:null,start:"1",offset:rowsPerPage);
//         yield FeaturedOffersSuccess(offersList);
//     }else if(event is GetFeaturedOffers){
//         var reqParam = {};
//         reqParam['viewFeaturedFeaturedOffers']="false";
//         final offersList = await _services.getOffers(data:reqParam,start:"1",offset:"3");
//         yield FeaturedOffersSuccess(offersList);
//     }
//   }
// }
