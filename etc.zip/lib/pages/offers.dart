import 'package:etc/bloc/bloc.dart';
import 'package:etc/bloc/offers/offers_bloc.dart';
import 'package:etc/components/loader.dart';
import 'package:etc/components/offerItem.dart';
import 'package:etc/helper/globals.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Offers extends StatefulWidget {
  final dynamic data;
  Offers({Key key, this.data}) : super(key: key);
  
  @override
  _OffersState createState() => _OffersState();
}

class _OffersState extends State<Offers> {

  void didChangeDependencies() {
    super.didChangeDependencies();
    print("=====");
    print(currentFilterParams);
    print("=====");
    BlocProvider.of<OffersBloc>(context)
      ..add(GetOffers(data:currentFilterParams));
  }

  @override
  Widget build(BuildContext context) {

    

    return Container(
      child: BlocBuilder<OffersBloc, OffersState>(
        builder: (context, state) {
          if (state is OffersSuccess) {
            final offerList = state.offers;
            print(offerList);
            return ListView.builder(
                itemCount: offerList.length,
                itemBuilder: (context, index) {
                      return Container(
                        height: 173.0,
                        child: OfferItem(
                          offerItem: offerList[index],
                        ),
                      );
                    });
          } else {
            return CustomLoader();
          }
        },
      ),
    );
  }
}
