import 'package:etc/bloc/authenticate/authenticate_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
class Splash extends StatefulWidget {
  Splash({Key key}) : super(key: key);

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:null,
      body:BlocConsumer<AuthenticateBloc,AuthenticateState>(
        listener: (context,state){
          if(state is AuthenticateSuccess){
            Navigator.of(context).pushReplacementNamed('/home');
          }
          if(state is AuthenticateError){
            Navigator.of(context).pushReplacementNamed('/welcome');
          }
        },
        builder: (context,state){
          if(state is! AuthenticateSuccess){
            return Container(
              child: Center(child: Image.asset('assets/img/logo.png', width: MediaQuery.of(context).size.width*0.6,),) ,);
          }else {
            return Container(child:null);
          }
      },)
    );
  }
}