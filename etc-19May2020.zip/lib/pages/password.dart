import 'package:etc/helper/globals.dart';
import 'package:etc/helper/services.dart';
import 'package:flutter/material.dart';
class Password extends StatefulWidget {

  Password({Key key}) : super(key: key);

  @override
  _PasswordState createState() => _PasswordState();
}

class _PasswordState extends State<Password> {
  
  final _passwordController = TextEditingController();
  bool _processing = false;
  dynamic voucher;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _doVerify(context) async {
    if(_passwordController.text=='' || _passwordController==null){
      Scaffold.of(context).showSnackBar(SnackBar(content: Text("Enter Valid Password", textAlign: TextAlign.center,), backgroundColor: Colors.red,));
    }else {
      _processing = true;
      setState(() {});
      //Validate outlet Pin
      //dealID,outletPIN,redeemVoucherCountRef
      var data = {};
      data['userPassword']= _passwordController.text;
      
      try {
        var outletPin = await Services().validateUser(data:data);
        print(outletPin);
        
        var dataR = {};
        dataR['dealID']=voucher['dealID'];
        dataR['userPassword']=_passwordController.text;
        dataR['redeemVoucherCountRef']=voucherCountRef;

        try {
          var voucherRedeem = await Services().redeemVoucher(data:dataR);
          print(voucherRedeem);
          _processing = false;
          setState((){});
          Navigator.of(context).pushReplacementNamed('/voucherCode',arguments: {"vcode":voucherRedeem['code'],"voucher":voucher});
        }catch (e){
          print(e);
          _processing = false;
          setState((){});
        }

      }catch (e){
        print(e);
        _passwordController.text = "";
        _processing = false;
        Scaffold.of(context).showSnackBar(SnackBar(content: Text("Invalid Password.", textAlign: TextAlign.center,), backgroundColor: Colors.red,));
        setState(() {});
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    final Map params = ModalRoute.of(context).settings.arguments as Map;
    voucher = params['voucher'];
    
    return Scaffold(
      appBar:AppBar(
        title:Text("Password"),
        centerTitle:true
      ),
      body: Builder(builder:(BuildContext context){
        return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: (){
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: Container(
            padding: EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(left: 15, right: 15, bottom: 35.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children:<Widget>[
                      Text("Verify It's You",style:TextStyle(fontSize: 22.0, fontWeight: FontWeight.w600, height: 1.3)),
                      Text("Enter your password to complete redemption.",style:TextStyle(fontSize: 16.0, fontWeight: FontWeight.w300, height: 1.3)),
                    ]
                  ),),
                Padding(
                    padding: EdgeInsets.only(left: 15, right: 15),
                    child: TextFormField(
                        controller: _passwordController,
                        textInputAction: TextInputAction.done,
                        autocorrect: false,
                        obscureText: true,
                        onChanged: (value) {},
                        // controller: editingController,
                        decoration: InputDecoration(
                            isDense: true,
                            contentPadding: EdgeInsets.all(12),
                            hintText: "Password",
                            hintStyle: TextStyle(color: grayColor),
                            fillColor: Colors.white,
                            filled: false,
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                borderSide: BorderSide(
                                    color: Color(0xFFced4d9), width: 1.0)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                borderSide: BorderSide(
                                    color: grayColor, width: 1.5))))),
                SizedBox(height: 15.0),
                // Padding(
                //   padding: EdgeInsets.only(left: 20.0, right: 20.0),
                //   child: RichText(
                //     textAlign: TextAlign.left,
                //     text: TextSpan(
                //         text: 'Forgot Password? ',
                //         style: TextStyle(color: Colors.black),
                //         children: [
                //           TextSpan(
                //               text: 'Reset',
                //               style: TextStyle(color: primaryColor)),
                //           TextSpan(text: " here")
                //         ]),
                //   ),
                // ),
                SizedBox(height: 25.0),
                Container(
                  margin: EdgeInsets.only(left:90.0, right:90.0),
                  child: RaisedButton(
                      onPressed: (!_processing) ? () { _doVerify(context); } : null,
                      color: primaryColor,
                      padding: EdgeInsets.only(left: 35.0, right: 35.0),
                      child: (!_processing)?Text("Verify",
                          style:
                              TextStyle(color: Colors.white, fontSize: 16.0)):Container(child: Text("Processing..."),)),
                ),
              ],
            ),
          ),);
      })
    );
  }
}