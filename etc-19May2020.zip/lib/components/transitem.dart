import 'package:etc/helper/globals.dart';
import 'package:etc/helper/methods.dart';
import 'package:flutter/material.dart';
class TransItem extends StatelessWidget {
  final dynamic transItem;
  const TransItem({Key key, this.transItem}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin:EdgeInsets.fromLTRB(10.0,5.0,10.0,5.0),
      padding:EdgeInsets.all(0.0),
      decoration: BoxDecoration(
        border:Border.all(color:Colors.black12)
      ),
      child: Row(
        children: <Widget>[
        Container(
          padding: EdgeInsets.all(10.0),
          decoration: BoxDecoration(
            color:blueColor
          ),
          child:Center(
            child: Column(children: <Widget>[
              Text(HelperMethods().formatDateTime(format:"dd MMM",dateTime:transItem['transactionDateTime']),style: TextStyle(color:Colors.white, fontSize: 16.0, fontWeight: FontWeight.w600, height: 1.2),),
              Text(HelperMethods().formatDateTime(format:"yyyy",dateTime:transItem['transactionDateTime']),style: TextStyle(color:Colors.white, fontSize: 14.0, fontWeight: FontWeight.w300, height: 1.2),)
            ],),
          )
        ),
        Container(
          width: MediaQuery.of(context).size.width*0.75,
          padding: EdgeInsets.only(left:5.0,top:5.0, bottom:5.0, right:5.0),
          child:Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
            Text(transItem['voucher']['discountType'] + " " + transItem['voucher']['voucherName'], style:TextStyle(color: darkGrayColor, fontWeight: FontWeight.w600, height: 1.3, fontSize: 16.0,), overflow: TextOverflow.ellipsis, textAlign: TextAlign.left,),
            Text(transItem['outlet']['outletName'] + " - " + transItem['outlet']['locality']['cluster'], style:TextStyle(color: darkGrayColor, fontWeight: FontWeight.w400, height: 1.3, fontSize: 14.0,), textAlign: TextAlign.left,),
          ],)
        )
      ],),
    );
  }
}